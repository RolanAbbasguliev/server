#!/usr/bin/env php

<?php

    print("Its php, im alive too\n");
    print("Next output is mine: \n\n\n");

    echo getenv('HEADERS_LIST');

?>